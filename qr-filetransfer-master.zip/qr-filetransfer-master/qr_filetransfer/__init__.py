from .qr_filetransfer import main
